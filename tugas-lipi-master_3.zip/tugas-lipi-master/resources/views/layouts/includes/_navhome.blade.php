<header id="header" class="fixed-top">
    <div class="container">

      <div class="logo float-left">
        <h1 class="text-light"><a href="/"><span>LIPI</span></a></h1>
        <!-- Uncomment below if you prefer to use an image logo -->
        <!-- <a href="index.html"><img src="assets/img/logo.png" alt="" class="img-fluid"></a>-->
      </div>
      
      
      <nav class="nav-menu float-right d-none d-lg-block">
          <ul>
              <li><a href="/">Dashboard</a></li>
              <li><a href="/kunjungan">Kunjungan</a></li>
              <li><a href="/penelitian">Penelitian</a></li>
              <li><a href="/kontak">Kontak kami</a></li>
              <li><a href="/login">Login</a></li>
            </ul>
        </nav>
        
    </div>
</header>